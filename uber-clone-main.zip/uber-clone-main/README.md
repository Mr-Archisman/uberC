## uber-clone

Uber clone in react native. 
- Navigation
- Redux, 
- Tailwind CSS
- Google Autocomplete
- Google map integration with price and distance matrix
- and a lot more

## installation

```
yern
```

or

```
npm install
```

### live demo on Expo

[Live demo](https://expo.io/@coderkhalid/projects/uber-clone)

# My Portfolio 
[khaliddev.com](https://www.khaliddev.com/)
