export default {
    primary: '#f8b718',
    secondary: '#462200',
    black: '#000',
    white: '#fff',
    medium: '#F3F3F3',
    gray: '#4D4D4E',
    light: '#F9F9F9',
    dark: '#0c0c0c',
    denger: '#E81A1A',
}